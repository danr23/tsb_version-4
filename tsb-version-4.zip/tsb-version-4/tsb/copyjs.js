function selectionClear() {
document.getElementById("tsbT").focus();
document.getElementById("tsbT").selectionEnd = 0;
}
function copy() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").focus();
document.getElementById("tsbT").selectionStart = 0;
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 1;
}, 100);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 2;
}, 200);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 3;
}, 300);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 4;
}, 400);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 5;
}, 500);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 6;
}, 600);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 7;
}, 700);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 8;
}, 800);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 9;
}, 900);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 10;
}, 1000);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 11;
}, 1100);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 12;
}, 1200);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 13;
}, 1300);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 14;
}, 1400);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 15;
}, 1500);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 16;
}, 1600);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 17;
}, 1700);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 18;
}, 1800);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 19;
}, 1900);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 20;
}, 2000);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 21;
}, 2100);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 22;
}, 2200);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 23;
}, 2300);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 24;
}, 2400);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 25;
}, 2500);
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 26;
}, 2600);
setTimeout(function() {
document.execCommand('copy');
document.getElementById("resultCopy").childNodes[0].nodeValue = document.getElementById("tsbT").value;
selectionClear();
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2700);
}
